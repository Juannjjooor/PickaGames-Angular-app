export interface DashboardGameData{
    
}