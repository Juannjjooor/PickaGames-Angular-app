export interface ModeData{
    mode_id: string
    name: string
}