export interface PegiData {
  pegi_id: string
  name: string
}
