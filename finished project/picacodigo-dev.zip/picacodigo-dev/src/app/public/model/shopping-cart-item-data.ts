export interface ShoppingCartItemData{
    user_id: string,
    game_id: string,
    game_quantity: number
}