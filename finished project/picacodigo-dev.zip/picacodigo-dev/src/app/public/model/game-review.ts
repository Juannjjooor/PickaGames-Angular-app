export interface GameReview{
    review_id: string
    content: string
    username: string 
    picture: string 
}
