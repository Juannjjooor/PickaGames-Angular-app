export interface GenreData{
    category_id: string
    name: string
}