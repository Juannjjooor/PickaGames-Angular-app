import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-addtokart',
  templateUrl: './invalid-addtokart.component.html',
  styleUrls: ['./invalid-addtokart.component.scss']
})
export class InvalidAddtokartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
