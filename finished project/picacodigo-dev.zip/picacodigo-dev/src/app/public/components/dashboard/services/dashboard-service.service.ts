import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductData } from 'src/app/shared/models/product-data';
import { GamePictureData } from 'src/app/public/model/game-picture-data';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

 

}
