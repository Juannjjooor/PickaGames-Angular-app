import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-need-login',
  templateUrl: './need-login.component.html',
  styleUrls: ['./need-login.component.scss']
})
export class NeedLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
