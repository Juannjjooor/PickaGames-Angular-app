export interface NewSaleData{
    date: Date
    amount: number
    game_id: string
    user_id: string
}