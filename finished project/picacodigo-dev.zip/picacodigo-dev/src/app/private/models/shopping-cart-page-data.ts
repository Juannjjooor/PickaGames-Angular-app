export interface ShoppingCartPageData{
    game_id: string
    game_name: string
    game_price: number
    game_quantity: number
    game_total_price: number
}