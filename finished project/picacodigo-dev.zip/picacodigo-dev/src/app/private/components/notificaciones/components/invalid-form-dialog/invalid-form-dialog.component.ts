import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'invalid-form-dialog',
  templateUrl: './invalid-form-dialog.component.html',
  styleUrls: ['./invalid-form-dialog.component.scss']
})
export class InvalidFormDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
