import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-valid-messageform-dialog',
  templateUrl: './valid-messageform-dialog.component.html',
  styleUrls: ['./valid-messageform-dialog.component.scss']
})
export class ValidMessageformDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
