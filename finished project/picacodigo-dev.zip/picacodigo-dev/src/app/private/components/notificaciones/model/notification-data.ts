export interface NotificationData{
    id: string,
    from: string,
    content: string,
    where: string,
    link: string,
    read: boolean
  }