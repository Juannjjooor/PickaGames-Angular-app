export interface Message {
    mail_to: string,
    message_text: string
}