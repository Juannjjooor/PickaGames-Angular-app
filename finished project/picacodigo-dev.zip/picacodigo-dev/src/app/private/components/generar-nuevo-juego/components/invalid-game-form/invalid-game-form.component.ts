import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-game-form',
  templateUrl: './invalid-game-form.component.html',
  styleUrls: ['./invalid-game-form.component.scss']
})
export class InvalidGameFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
