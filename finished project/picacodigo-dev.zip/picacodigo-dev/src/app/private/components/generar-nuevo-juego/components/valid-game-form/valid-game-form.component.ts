import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-valid-game-form',
  templateUrl: './valid-game-form.component.html',
  styleUrls: ['./valid-game-form.component.scss']
})
export class ValidGameFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
