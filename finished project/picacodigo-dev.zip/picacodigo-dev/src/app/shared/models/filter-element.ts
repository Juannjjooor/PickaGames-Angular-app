export interface FilterElement {
    id: string,
    name: string
}

export interface SelectedFilter {
    genres: string[],
    modes: string[]
}