import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-permission',
  templateUrl: './not-permission.component.html',
  styleUrls: ['./not-permission.component.scss']
})
export class NotPermissionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
